/*
 * $safeitemname$.cpp
 *
 * Created: $time$
 * Author: $username$
 */ 

#include "MyClass.h"

void MyClass::setup()
{

}

void MyClass::loop()
{

}

MyClass myClass;

